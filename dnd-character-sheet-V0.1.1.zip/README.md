# D&D Character Sheet — V0.1

Seconda build: prima V0.1 funzionale del prototipo Monaco.

Include:
- Umano 2014 (+1 a tutte le caratteristiche)
- Standard Array assegnabile liberamente
- Point Buy 27
- 4d6 con dadi visibili e assegnazione dei risultati
- Inserimento manuale
- Scheda mobile più vicina alla scheda cartacea
- PF, PF temporanei e TS contro morte interattivi
- Dadi Vita d8 e uso durante riposo breve
- Ki scalabile e recupero
- Progressione Monaco fino al livello 5 con capacità
- Scelta Tradizione Monastica al livello 3
- ASI / talento al livello 4
- PF aumentati a ogni livello
- Salvataggio locale del personaggio

Nota: descrizioni integrali e pagine dei manuali sono lasciate come segnaposto finché non vengono verificate sulle fonti fornite.


## V0.1.1
- Valori standard assegnabili liberamente.
- Umano 2014: +1 a tutte le caratteristiche.
- Tiro 4d6 visibile con dado più basso scartato.
- Progressione Monaco: PF, Ki, Dadi Vita e capacità per livello.
- Scelta Tradizione Monastica al livello 3.
- ASI (+2 / +1+1) o talento al livello 4.
- Riposo breve/lungo e consumo Ki.
- Salvataggio locale del personaggio.
- Safe area inferiore per non coprire i controlli con la barra Android.
- Versione Android 0.1.1 build 3 per consentire l'aggiornamento quando package e firma coincidono.
